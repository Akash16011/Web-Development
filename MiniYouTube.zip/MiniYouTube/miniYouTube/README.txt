=> tplawesome is a light and easy to use template engine.
   The only thing it does is replacing {{keys}} from an HTML template with formatted JSON data