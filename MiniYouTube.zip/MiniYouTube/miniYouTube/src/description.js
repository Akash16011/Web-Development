var description = {
	videoDescription: function (description) {

		$('.description').append(description);

	}

}

module.exports = description;