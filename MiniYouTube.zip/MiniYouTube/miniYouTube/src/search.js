var search = {
    searchResult: function (url,searchTerm,callback) {
       
        // console.log(searchTerm);
        searchTerm:encodeURIComponent(searchTerm).replace(/%20/g, "+");
        
        // printSearchTerm: encodeURIComponent(searchTerm).replace(/%20/g, "+");
        // console.log(printSearchTerm);

        $.ajax({
            url: url,
            method: 'GET',
            data: {
                part: 'snippet',
                type: 'video',
                q: searchTerm,
                maxResults: '6',
                key: 'AIzaSyCuxUl9iILnfEGp1uVyAn-ngVKJXOTg_0E'

            },
            dataType: 'json',

            success: function (data) {
                callback(data.items);
            }
        });

    }

}
module.exports = search;

