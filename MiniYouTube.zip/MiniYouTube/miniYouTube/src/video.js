var search = require('./search');


function tplawesome(template, data) {
	// initiate the result to the basic template
	res = template;
	// for each data key, replace the content of the brackets with the data
	for (var i = 0; i < data.length; i++) {
		res = res.replace(/\{\{(.*?)\}\}/g, function (match, j) { // some magic regex
			return data[i][j];
		})
	}
	return res;
} // and that's it!



var vid = {
	video: function (videoId) {
		$.get("/miniYouTube/dist/video.html", function (data) {
			if ($('.selected-video .video-cont').length > 0) {
				$('.selected-video .video-cont').remove();
				$('.selected-video').append(tplawesome(data, [{ "videoid": videoId }]));
			} else {
				$('.selected-video').append(tplawesome(data, [{ "videoid": videoId }]));
			} //shift 
			//   location.reload();
		});
	}
}
module.exports = vid;

