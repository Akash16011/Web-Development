// import _ from 'lodash';
var search = require('./search');
var thumbnails = require("./thumbnail");
var vid = require('./video');
var description = require('./description');
var storeSearchData;

$('#search-button').click(function () {
	// console.log('hello');
	var searchTerm = $(".search-bar").val();
	search.searchResult('https://www.googleapis.com/youtube/v3/search', searchTerm, vidDetails);

});

function vidDetails(vidData) {

	console.log(vidData);

	storeSearchData = vidData;

	vid.video(vidData[0].id.videoId);
	description.videoDescription(vidData[0].snippet.description);


	vidData.forEach(function (item, index) {
		if (index < 1) return;
		thumbnails.videoThumbnails(item);
	})
}


$('.thumbnails').on('click', '.thumbs', function () {
	// alert("Thumbnail work");
	var vID = $(this).data('id');

	alert(vID);
	search.searchResult('https://www.googleapis.com/youtube/v3/search', vID, vidDetails);
});

