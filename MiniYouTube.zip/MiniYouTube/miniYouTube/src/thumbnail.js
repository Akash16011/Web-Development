var search = require('./search');

function tplawesome(template, data) {
	// initiate the result to the basic template
	res = template;
	// for each data key, replace the content of the brackets with the data
	for (var i = 0; i < data.length; i++) {
		res = res.replace(/\{\{(.*?)\}\}/g, function (match, j) { // some magic regex
			return data[i][j];
		})
	}
	return res;
} // and that's it!


var thumbnails = {
	videoThumbnails: function (thumbnails) {
		// console.log(thumbnails);
		var tURL = thumbnails.snippet.thumbnails.high.url;
		var vTitle = thumbnails.snippet.title;
		var vchannelTitle = thumbnails.snippet.channelTitle;
		var videoID = thumbnails.id.videoId;

		//   console.log(vchannelTitle);

		$.get("/miniYouTube/dist/thumbnail.html", function (data) {

			$('.thumbnails').append(tplawesome(data, [{ "thumbnailsProp": tURL, "title": vTitle, "channelTitle": vchannelTitle, "videoID": videoID }]));
		});

	}
}

module.exports = thumbnails;